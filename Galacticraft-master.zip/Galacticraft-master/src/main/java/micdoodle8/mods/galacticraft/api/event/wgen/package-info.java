@API(apiVersion = "1.0", owner = "galacticraftcore", provides = "Galacticraft API") package micdoodle8.mods.galacticraft.api.event.wgen;

import net.minecraftforge.fml.common.API;

