package micdoodle8.mods.galacticraft.api.entity;

public interface IIgnoreShift
{
    boolean shouldIgnoreShiftExit();
}
