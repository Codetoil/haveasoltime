package micdoodle8.mods.galacticraft.api.item;

public interface ISensorGlassesArmor 
{

}
