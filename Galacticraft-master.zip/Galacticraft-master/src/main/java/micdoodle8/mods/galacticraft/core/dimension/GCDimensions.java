package micdoodle8.mods.galacticraft.core.dimension;

import net.minecraft.world.DimensionType;

public class GCDimensions
{
    public static DimensionType MOON;
    public static DimensionType ORBIT;
    public static DimensionType ORBIT_KEEPLOADED;
}
