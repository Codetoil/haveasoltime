package micdoodle8.mods.galacticraft.api.item;

public enum EnumExtendedInventorySlot
{
    MASK,
    GEAR,
    LEFT_TANK,
    RIGHT_TANK,
    PARACHUTE,
    FREQUENCY_MODULE,
    THERMAL_HELMET,
    THERMAL_CHESTPLATE,
    THERMAL_LEGGINGS,
    THERMAL_BOOTS,
    SHIELD_CONTROLLER
}
