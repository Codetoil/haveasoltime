@API(apiVersion = "1.1", owner = "galacticraftcore", provides = "Galacticraft API") package micdoodle8.mods.galacticraft.api.prefab.entity;

import net.minecraftforge.fml.common.API;

