package micdoodle8.mods.galacticraft.core.entities;

import micdoodle8.mods.galacticraft.core.tile.TileEntityDungeonSpawner;

public interface IBoss
{
    void onBossSpawned(TileEntityDungeonSpawner spawner);
}
