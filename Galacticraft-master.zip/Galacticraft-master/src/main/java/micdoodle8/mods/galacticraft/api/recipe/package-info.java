@API(apiVersion = "1.2", owner = "galacticraftcore", provides = "Galacticraft API") package micdoodle8.mods.galacticraft.api.recipe;

import net.minecraftforge.fml.common.API;

