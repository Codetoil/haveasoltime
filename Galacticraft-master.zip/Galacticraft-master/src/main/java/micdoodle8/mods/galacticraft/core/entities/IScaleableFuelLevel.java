package micdoodle8.mods.galacticraft.core.entities;

public interface IScaleableFuelLevel
{
    int getScaledFuelLevel(int scale);
}
