package micdoodle8.mods.galacticraft.core.entities;

public interface IControllableEntity
{
    boolean pressKey(int key);
}
