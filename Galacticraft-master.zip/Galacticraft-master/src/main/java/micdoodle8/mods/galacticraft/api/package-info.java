@API(apiVersion = "1.0", owner = "galacticraftcore", provides = "Galacticraft API") package micdoodle8.mods.galacticraft.api;

import net.minecraftforge.fml.common.API;
