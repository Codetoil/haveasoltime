package micdoodle8.mods.galacticraft.api.entity;

import net.minecraft.world.World;

public interface IWorldTransferCallback
{
    void onWorldTransferred(World world);
}
