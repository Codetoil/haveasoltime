package micdoodle8.mods.galacticraft.api.entity;

/**
 * Used for non-living, but laser turret targettable entities
 */
public interface ILaserTrackableFast
{
}
