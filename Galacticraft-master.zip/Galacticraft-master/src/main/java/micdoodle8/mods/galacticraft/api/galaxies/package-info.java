@API(apiVersion = "1.3", owner = "galacticraftcore", provides = "Galacticraft API") package micdoodle8.mods.galacticraft.api.galaxies;

import net.minecraftforge.fml.common.API;

